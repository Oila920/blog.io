//
//  dog.m
//  kvcdemo
//
//  Created by Oila on 2017/9/19.
//  Copyright © 2017年 Oila. All rights reserved.
//

#import "dog.h"

@implementation dog
{
    NSString *name;
    int       age;
    BOOL      sex;
}
@end
