//
//  ViewController.m
//  kvcdemo
//
//  Created by Oila on 2017/9/19.
//  Copyright © 2017年 Oila. All rights reserved.
//

#import "ViewController.h"
#import "dog.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    dog *bigDog = [[dog alloc]init];
    NSLog(@"age>>>%@",[bigDog valueForKey:@"age"]);
    [bigDog setValue:@"5" forKey:@"age"];
    NSLog(@"age>>>%@",[bigDog valueForKey:@"age"]);

    NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithObjectsAndKeys:@"tom",@"name",@"5",@"age",@"YES",@"sex", nil];
    
    [bigDog setValuesForKeysWithDictionary:dic];
    NSLog(@"age>>>%@,name>>>%@,sex>>>%@",[bigDog valueForKey:@"age"],[bigDog valueForKey:@"name"],[bigDog valueForKey:@"sex"]);
    
    
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
